The format of the CPCP instances from set S2 are organized as follows:

- First line contains the "number of nodes (n)", and the "maximum number of facilities to be opened (p)", respectively;
- Second line contains contains the capacity values for nodes 0, 1, 2, ..., n-1, respectively.
- Third line contains contains the demand values for nodes 0, 1, 2, ..., n-1, respectively.
- 4th line contains the distance values from node 0 to nodes 0, 1, 2, ..., n-1, respectively.
- 5th line contains contains the distance values from node 1 to nodes 0, 1, 2, ..., n-1, respectively.
- (...)
- (n+3)-th line contains the distance values from node n-1 to nodes 0, 1, 2, ..., n-1, respectively.

--
Reference
- Scaparra M, Pallottino S, Scutellà M (2004) Large-scale local search heuristics for the 
capacitated vertex p-center problem. Networks 43(4):241–255. Available at https://doi.org/10.1002/net.20000. 

These instances are available at http://www.di.unipi.it/optimize/Data/MEX.html, more precisely at 
http://www.di.unipi.it/optimize/Data/mexch/GalvaoData.tar.Z. 

These instances are also available at http://www.or.unimore.it/resources/CPCP/instances.html.
