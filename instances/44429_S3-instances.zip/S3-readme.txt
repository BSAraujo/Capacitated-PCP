The format of the CPCP instances from set S3 are organized as follows:

- First line contains the "number of nodes (n)", and the "maximum number of facilities to be opened (p)", respectively;
- Second line contains the x-coordinate, the y-coordinate, the capacity, and the demand, respectively, of node 0.
- Third line contains the x-coordinate, the y-coordinate, the capacity, and the demand, respectively, of node 1.
- (...)
- (n+1)-th line contains the x-coordinate, the y-coordinate, the capacity, and the demand, respectively, of node n-1.

--
Reference
- Lorena L, Senne E (2004) A column generation approach to capacitated p-median problems. Computers & Operations 
Research 31(6):863–876.

These instances are originally available at http://www.lac.inpe.br/%7Elorena/instancias.html. They are also 
available at http://www.or.unimore.it/resources/CPCP/instances.html.
