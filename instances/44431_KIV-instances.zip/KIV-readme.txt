The format of the CPCP instances from set KIV, proposed in "Mathematical models and search algorithms for the capacitated p-center problem" 
by Kramer, Iori, and Vidal (2017), are organized as follows:

- First line contains the "number of nodes (n)", and the "maximum number of facilities to be opened (p)", respectively;
- Second line contains the x-coordinate, the y-coordinate, the capacity, and the demand, respectively, of node 0.
- Third line contains the x-coordinate, the y-coordinate, the capacity, and the demand, respectively, of node 1.
- (...)
- (n+1)-th line contains the x-coordinate, the y-coordinate, the capacity, and the demand, respectively, of node n-1.

--
Reference
Kramer, R., Iori, M., Vidal, T. (2017) "Mathematical models and search algorithms for the capacitated p-center problem".
Technical report. Available at http://www.or.unimore.it/resources/CPCP/home.html.

These instances are available at http://www.or.unimore.it/resources/CPCP/instances.html.
